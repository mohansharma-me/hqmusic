<?php
echo "Data:".stream_get_line(STDIN, 1024, PHP_EOL);