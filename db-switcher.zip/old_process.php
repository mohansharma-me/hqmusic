<?php
/*** Internal Initilization ***/
$args=$argv; // command line arguments
$old_err_report=error_reporting(0);
if(isset($args[1])) {
	if($args[1]=="0")
		error_reporting($args[1]);
	if($args[1]=="1")
		error_reporting($old_err_report);
}
function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 

    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 

    // Uncomment one of the following alternatives
     $bytes /= pow(1024, $pow);
    // $bytes /= (1 << (10 * $pow)); 

    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 
function recursive_array_replace($find, $replace, $array){
    if (!is_array($array)) {
        $arr=explode(" ",trim($array));
        $output="";
        foreach($arr as $ar) {
            if($output==" ") {
                $output=preg_replace($find,$replace,$ar);
            } else {
                $output.=" ".preg_replace($find,$replace,$ar);
            }
        }
        return $output;
        //return preg_replace($find,$replace,$array);
    } else {
		//echo "<pre>";
		//print_r($array);
		//echo "</pre>";
	}
    $newArray = array();
    foreach ($array as $key => $value) {
            $newArray[$key] = recursive_array_replace($find, $replace, $value);
    }
    return $newArray;
}

function replaceIDTags($file,$poster,$sa,$domain="HQMusic.in") {
    $tagging_format = "UTF-8";
    $path = $file;
    require_once('./getid3/getid3.php');
    require_once('./getid3/write.php');

    $getID3 = new getID3;
    $getID3->setOption(array('encoding'=>$tagging_format));
    $tagdata = $getID3->analyze($path);
    if(isset($tagdata["tags"]["id3v2"])) {
        $tagdata = $tagdata['tags']['id3v2'];
    } else {
        $tagdata["title"]=array($sa["song_name"]);
        $tagdata["artists"]=array($sa["album_cast"]);
        $tagdata["album-artists"]=array($sa["album_cast"]);
        $tagdata["album"]=array($sa["album_name"]." - $domain");
        $tagdata["year"]=array($sa["album_year"]);
		$tagdata["composer"]=$tagdata["performer"]=$tagdata["lyricts"]=$tagdata["conductors"]=$tagdata["publisher"]=$tagdata["url"]=array("$domain");
		
        try {
            $json=json_decode($sa["album_imdb_json"],true);
            $tagdata["genre"]=array($json["genre"]);
            $tagdata["director"]=array($json["director"]);
            $tagdata["actors"]=array($json["actors"]);
        } catch (Exception $ex) {

        }
    }
	
	$tagdata["title"]=array($sa["song_name"]);
	$tagdata["artists"]=array($sa["album_cast"]);
	$tagdata["album-artists"]=array($sa["album_cast"]);
	$tagdata["album"]=array($sa["album_name"]." - $domain");
	$tagdata["year"]=array($sa["album_year"]);
	
	$tagdata["composer"]=$tagdata["performer"]=$tagdata["lyricts"]=$tagdata["conductors"]=$tagdata["publisher"]=$tagdata["url"]=array("$domain");
	try {
		$json=json_decode($sa["album_imdb_json"],true);
		$tagdata["genre"]=array($json["genre"]);
		$tagdata["director"]=array($json["director"]);
		$tagdata["actors"]=array($json["actors"]);
	} catch (Exception $ex) {

	}
    $patern="/^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$/";
    $tagdata = recursive_array_replace($patern,$domain,$tagdata);
    $tagwriter = new getid3_writetags;
    $tagwriter->filename = $path;
    $tagwriter->tagformats = array('id3v1', 'id3v2.3');
    $tagwriter->overwrite_tags = true;
    $tagwriter->tag_encoding = $tagging_format;
    $tagwriter->remove_other_tags = true;

    //read the APIC
    ob_start();
    if($fd = fopen($poster,'rb'))
    {
        ob_end_clean();
        $image_data = fread($fd,filesize($poster));
        fclose($fd);
    }

    $tagdata['attached_picture'][0]['data'] = $image_data;
    $tagdata['attached_picture'][0]['picturetypeid'] = "3";
    $tagdata['attached_picture'][0]['description'] = $domain;
    $tagdata['attached_picture'][0]['mime'] = "image/png";

    $tagwriter->tag_data = $tagdata;

	unset($tagdata["comment"]);
	
	$oflag=$tagwriter->WriteTags();
		//echo "<pre>";
		//print_r($tagwriter->errors);	
		//echo "</pre>";
		$_GET["tagError"]=$tagwriter->errors;
    if($oflag)
    {
//		echo "YES";
        return true;
    }
    else
    {
//		echo "NO";
        return false;
    }
}
function err($msg) {
	echo "\nERROR: ".$msg."\n\n";
}
function slug($text) {
	 // replace non letter or digits by -
  $text = preg_replace('~[^\\pL\d]+~u', '-', $text);

  // trim
  $text = trim($text, '-');

  // transliterate
  $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

  // lowercase
  $text = strtolower($text);

  // remove unwanted characters
  $text = preg_replace('~[^-\w]+~', '', $text);

  if (empty($text))
  {
    return 'n-a';
  }
  
  return $text;
}
function rline($cmd,$default="") {
	if(PHP_OS=="WINNT") {
		echo $cmd;
		$line=stream_get_line(STDIN, 1024, PHP_EOL);
	} else {
		$line=readline($cmd);
	}
	if(strlen(trim($line))==0) {
		return $default;
	} else {
		return $line;
	}
}
function getPoster($poster,$slug) {
	$default=false;
	$poster=trim($poster);
	$img=null;
	if(strlen($poster)>0) {
		$data=file_get_contents($poster);
		if(strlen($data)<=0) {
			$poster="./qrcode.png";
			$default=true;
		} else {
			file_put_contents("./temp_poster_original",$data);
			$poster="./temp_poster_original";
		}
	} else {
		$poster="./qrcode.png";
		$default=true;
	}
	if($default) {
		echo "\tUsing QRCODE Image\n";
		$img=imagecreatefrompng($poster);
	} else {
		echo "\tUsing IMDB Image\n";
		$img=imagecreatefromjpeg($poster);
	}
	mkdir("./images",0755,true);
	$wm_path="./watermark.png";
	$wm=imagecreatefrompng($wm_path);
	list($w1,$h1)=getimagesize($wm_path);
	if($img!=null) {
		echo "\tGenerating 600 Poster\n";
		imagepng($img,"./images/$slug"."_original",9);
		
		$ori_size=600;					
		list($wid,$hei)=  getimagesize($poster);
		$o_w=$wid;
		$o_h=$hei;
		if($wid>$hei) {
			$hei=($hei*$ori_size)/$wid;
			$wid=$ori_size;
		} else {
			$wid=($wid*$ori_size)/$hei;
			$hei=$ori_size;
		}
		$thumb=imagecreatetruecolor($wid, $hei);
		
		imagecopyresized($thumb, $img, 0, 0, 0, 0, $wid, $hei, $o_w, $o_h);
		if(!$default) {
			imagecopyresized($thumb,  $wm, 0, $hei-$h1, 0, 0, $wid,$h1,$w1,$h1);
		}
		imagepng($thumb, "./images/$slug"."_300",9);
		imagedestroy($thumb);

		echo "\tGenerating THUMB Poster\n";
		$ori_size=64;
		list($wid,$hei)=  getimagesize($poster);
		$o_w=$wid;
		$o_h=$hei;
		if($wid>$hei) {
			$hei=($hei*$ori_size)/$wid;
			$wid=$ori_size;
		} else {
			$wid=($wid*$ori_size)/$hei;
			$hei=$ori_size;
		}
		$thumb=imagecreatetruecolor($wid, $hei);
		imagecopyresized($thumb, $img, 0, 0, 0, 0, $wid, $hei, $o_w, $o_h);
		imagepng($thumb, "./images/$slug"."_thumb",9);
		imagedestroy($thumb);
		
		imagedestroy($img);
		return true;
	} else {
		imagedestroy($img);
		return getPoster("");
	}
	imagedestroy($img);
	return false;
}

echo "HQMusic.in SCRAPPER\n\n";

/* read directory paths */
ask_from_dir:
$from_dir=rline("Source Dir [data] := ","data");
if(!file_exists("./$from_dir") || !is_dir("./$from_dir")) {
	err("[./$from_dir] Directory Not Found.");
	goto ask_from_dir;
}
ask_to_dir:
$to_dir=rline("Destination Dir [files] := ","files");
if(!is_dir("./$to_dir")) {
	if(file_exists("./$to_dir")) {
		unlink("./$to_dir");
	}
	if(mkdir("./$to_dir")) {
		echo "[./$to_dir] Directory Created!\n";
	} else {
		err("Can't create destination directory [./$to_dir].");
		exit(0);
	}
}
echo "\n";

/* read database connecion info */
$mysql_server="localhost";
$mysql_username="root";
$mysql_password="";
ask_mysql_connection:$mysql_server=rline("Enter MySQL Server [$mysql_server] := ",$mysql_server);
$mysql_username=rline("Enter MySQL Username [$mysql_username] := ",$mysql_username);
$mysql_password=rline("Enter MySQL Password := ",$mysql_password);
echo "\n[Connecting to MySQL Server] Please Wait...\n";
$conn_s=mysql_connect($mysql_server,$mysql_username,$mysql_password);
$conn_d=mysql_connect($mysql_server,$mysql_username,$mysql_password);
if(!$conn_s || ($conn_s && !is_resource($conn_s))) {
	err("Can't connect to $mysql_username@$mysql_server.");
	goto ask_mysql_connection;
}
if(!$conn_d || ($conn_d && !is_resource($conn_d))) {
	err("Can't connect to $mysql_username@$mysql_server.");
	goto ask_mysql_connection;
}
echo "[Connection Established] $conn\n\n";

echo "Database on $mysql_username@$mysql_server \n";
$result=mysql_query("show databases");
if(mysql_affected_rows()==0) {
	err("[No Databases] There is no database in connected server.");
	goto ask_mysql_connection;
} else if(mysql_affected_rows()>0) {
	$i=0;
	while($row=mysql_fetch_assoc($result)) {
		echo "\t-> ".$row["Database"]."\n";
	}
	echo "\n";
}

$conn_s_db=null;
$conn_d_db=null;

$scraper_db="scraper_db";
ask_s_db:$scraper_db=rline("Scraper DB Name [$scraper_db] := ",$scraper_db);
$conn_s_db=mysql_select_db($scraper_db,$conn_s);
if(!$conn_s_db) {
	err("[$scraper_db] Database Not Found.");
	goto ask_s_db;
}
$result=mysql_query("SHOW TABLES");
if(mysql_affected_rows()<=0) {
	err("[$scraper_db] Doest Not Contain Valid Tables.");
	goto ask_s_db;
} else {
	$flag=0;
	while($row=mysql_fetch_row($result)) {
		if($row[0]=="albums")
			$flag++;
		if($row[0]=="songs")
			$flag++;
	}
	if($flag<2) {
		err("[$scraper_db] Doest not contain 'albums' and 'songs' table.");
		goto ask_s_db;
	}
}

$hqmusic_db="hqmusic";
ask_d_db:$hqmusic_db=rline("HQMusic DB Name [$hqmusic_db] := ",$hqmusic_db);
$conn_d_db=mysql_select_db($hqmusic_db,$conn_d);
if(!$conn_d_db) {
	err("[$hqmusic_db] Database Not Found.");
	goto ask_d_db;
}

$category_id=1;
$category_slug="mp3-songs/bollywood-songs";
ask_category:$category_id=rline("Enter Sub-Category ID [$category_id]:",$category_id);
$category_slug=rline("Enter Sub-Category Slug [$category_slug]:",$category_slug);

echo "\n\n\n";
confirm_move:$confirm=rline("NOTE: If any data in `$hqmusic_db` database and directory `./$to_dir` resides it will be deleted.\n\nAre you sure to proceed next and START transfer ? [YES/NO] := ","YES");
$transfered=false;
if(strtolower(trim($confirm))=="yes") {
	$transfered=true;
	mysql_select_db($scraper_db);
	$result=mysql_query("select * from albums",$conn_s);
	if(mysql_affected_rows()<=0) {
		if(mysql_affected_rows()==0) {
			echo "0 album(s) found.\n\n";
		} else if(mysql_affected_rows()<0) {
			err("[MySQL Error] While Getting Album List\n (".mysql_error().")");
		}
	} else {
		while($album=mysql_fetch_assoc($result)) {
			echo "\n[".$album["id"]."] ".$album["name"]."\n";
			
			$old_id=$album["id"];
			$name=$album["name"];
			$json=trim($album["imdb_json"]);
			$desc="";
			$slug=slug($name);
			$year="";
			$cast="";
			$poster="";
			
			if($json=="N/A") {
				echo "\tIMDB JSON not found.\n";
			} else {
				echo "\tOperating JSON\n";
				try {
					$js=json_decode($json,true);
					if(isset($js["Plot"])) {
						$desc=$js["Plot"];
					}
					if(isset($js["Year"])) {
						$year=$js["Year"];
					}
					if(isset($js["Actors"])) {
						$cast=$js["Actors"];
					}
					if(isset($js["Poster"])) {
						$poster=$js["Poster"];
					}
				} catch(Exception $e) {
					echo "\tError while Operating JSON\n";
				}
			}
			$posterSet=getPoster($poster,$slug);
			if($posterSet) {
				echo "\tPoster Uploaded\n";
			} else {
				echo "\tFailed to upload Poster.\n";
			}
			mysql_select_db($hqmusic_db);
			mysql_query("insert into albums(album_category_id,album_name,album_description,album_slug,album_year,album_cast,album_imdb_json) values($category_id,'".mysql_escape_string($name)."','".mysql_escape_string($desc)."','$slug','$year','$cast','".mysql_escape_string(strtolower($json))."')");
			if(mysql_affected_rows()==1) {
				echo "\tAlbum Added.\n";
				$temp_res=mysql_query("select LAST_INSERT_ID() as lid;");
				$new_arr=mysql_fetch_assoc($temp_res);
				$new_id=$new_arr["lid"];
				mysql_select_db($scraper_db);
				$songs_res=mysql_query("select * from songs where album_id=$old_id");
				if(mysql_affected_rows()<=0) {
					echo "\tNo Songs Found.\n";
				} else {
					echo "\t".mysql_affected_rows()." song(s) found.\n";
					while($song=mysql_fetch_assoc($songs_res)) {
						$song_id=$song["id"];
						$song_name=$song["name"];
						$song_links=$song["data_links"];
						$song_slug=slug($song_name);
						echo "\t\t[$song_id] $song_name ";
						
						mysql_select_db($hqmusic_db);
						mkdir("./$to_dir/$category_slug/$slug/$song_slug",0755,true);
						mysql_query("insert into songs(song_album_id,song_name,song_slug) values($new_id,'$song_name','$song_slug')");
						if(mysql_affected_rows()<=0) {
							echo "[Can't add SONG to database]\n";
						} else {
							$temp_res=mysql_query("select LAST_INSERT_ID() as lid;");
							$new_arr=mysql_fetch_assoc($temp_res);
							$new_song_id=$new_arr["lid"];
							$files=explode(",",$song_links);
							if(count(explode(",",$song_name))>0) {
								$files=array($song_links);
							}
							if(count($files)>1) {
								echo " [128, 320]\n";
							} else {
								echo " [128]\n";
							}
							
							$first=true;
							foreach($files as $file) {
								$file=basename($file);
								$full_path="./$from_dir/$old_id/$file";
								if(file_exists($full_path) && is_file($full_path)) {
									$kbps="";
									if($first) {
										$kbps="128";
										$first=false;
									} else {
										$kbps="320";
									}
									$to_file="./$to_dir/$category_slug/$slug/$song_slug/$kbps.mp3";
									echo "\t\t\tMoving";
									if(rename($full_path,$to_file)) {
										echo " [DONE]\n";
										$sa=array("song_name"=>$song_name,"album_name"=>$name,"album_cast"=>$cast,"album_year"=>$year,"album_imdb_json"=>$json);
										$fPoster="./images/$slug"."_300";
										$file_flag=1;
										echo "\t\t\tTagging ";
										if(replaceIDTags($to_file,$fPoster,$sa)) {
											$file_flag=0;
											echo "[DONE]\n";
										} else {
											echo "[FAILED]\n";
											$file_flag=json_encode($_GET["tagError"]);
										}
										mysql_query("insert into files(file_song_id,kbps,file_size,file_flag) values($new_song_id,'$kbps','".formatBytes(filesize($to_file))."','$file_flag')");
										if(mysql_affected_rows()==1) {
											echo "\t\t\tADDED.\n";
										} else {
											echo "\t\t\tNOT ADDED.\n";
										}
									} else {
										echo " [FAILED]\n";
									}
								} else {
									echo "\t\t\tFile not found\n";
								}
							}
						}
					}
				}
			} else {
				echo "\tCan't add ALBUM to Database.\n";
				echo "\t\t[Error Msg] ".mysql_error()."\n";
			}
		}
	}
}

if($transfered) {
	err("[Script Terminated] Transfer successfully completed.");
} else {
	err("[Script Terminated] Transfer not completed.");
}
exit(0);
