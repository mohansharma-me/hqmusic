<div class="window">
    <div class='header'>
        <?php
            include_once "./contents/admin/icon-links.php";
        ?>
    </div>
    <div class='content'>
        <h2>New Update...</h2>
		<form class='form1'>
			<fieldset>
				<label>Select Album:</label>
				<input type="text" name="album" id="albumSearch" placeholder="Search Album" />
			</fieldset>
        </form>
    </div>
</div>