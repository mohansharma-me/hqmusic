<div class="window">
    <div class='header'>
        <?php
            include_once "./contents/admin/icon-links.php";
        ?>
    </div>
    <div class='content'>
        <br/><br/>
        <center>
            Please choose one of option from above...
        </center>
        <br/><br/>
    </div>
</div>