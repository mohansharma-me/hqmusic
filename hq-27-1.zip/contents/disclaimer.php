<br/>
<h2>Disclaimer</h2>
<br/>
<center>
<p>This is DEMO content for your data about Disclaimer.</p>
<p>You can write as many as possible P tag here one by one</p>
</center>
<br/>
<br/>