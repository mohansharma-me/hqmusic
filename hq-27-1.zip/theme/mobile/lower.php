            <div class="footer">
                <a href="">&copy; Copyright 2014, HQMusic.in</a><br/>
                <div class="links">
                    <a href="/dmca">DMCA</a> | <a href="/privacy-policy">Privacy Policy</a> | <a href="/disclaimer">Disclaimer</a>
                </div>
            </div>
			<?php
			include_once "./script.footer.php";
			?>
        </div>
    </body>
</html>